# -*- coding:utf-8 -*- 

"""
University of Sherbrooke
Date:
Authors: Mamadou Mountagha BAH & Pierre-Marc Jodoin
License:
Other: Suggestions are welcome
"""

import torch.nn as nn
from model.CNNBaseModel import CNNBaseModel
from layers.CNNBlocks import ResidualBlock, DenseBlock, BottleneckBlock

'''

Le réseau est constitué de

    1) quelques opérations de base du type « conv-batch-norm-relu »
    2) 1 (ou plus) bloc dense inspiré du modèle « denseNet)
    3) 1 (ou plus) bloc résiduel inspiré de « resNet »
    4) 1 (ou plus) bloc de couches « bottleneck » avec ou sans connexion résiduelle, c’est au choix
    5) 1 (ou plus) couches pleinement connectées 
    
    NOTE : le code des blocks résiduels, dense et bottleneck est dans le fichier CNNBlocks.py

'''


class IFT780Net(CNNBaseModel):
    """
    Class that mix up several sort of layers to create an original network
    """

    def __init__(self, num_classes=10, init_weights=True):
        """
        Args:
            num_classes(int): number of classes. default 10(cifar10 or svhn)
            init_weights(bool): when true uses _initialize_weights function to initialize
            network's weights.
        """
        super(IFT780Net, self).__init__()

        self.conv_block1 = self._make_conv_block(3, 32)
        self.conv_block2 = self._make_conv_block(32, 64)
        self.dense_block1 = DenseBlock(64)
        self.dense_block2 = DenseBlock(128)
        self.res_block = self._make_res_block(256, 512, 2)
        self.bottleneck_block = BottleneckBlock(512)
        self.fc_block = nn.Sequential(
            nn.Linear(512 * 2 * 2, 1024),
            nn.ReLU(inplace=True),
            nn.Linear(1024, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.2),
            nn.Linear(512, num_classes)
        )

    @staticmethod
    def _make_conv_block(in_channels, out_channels):
        """
        Function that returns a convolution block.
        """
        return nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=out_channels, out_channels=out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )

    @staticmethod
    def _make_res_block(in_channels, out_channels, stride=1):
        """
        Function that returns two residuals blocks
        """
        layers = list()
        layers.append(ResidualBlock(in_channels=in_channels, out_channels=out_channels, stride=stride))
        layers.append(ResidualBlock(in_channels=out_channels, out_channels=out_channels, stride=1))
        return nn.Sequential(*layers)

    def forward(self, x):
        """
        Forward pass of the model
        Args:
             x: Tensor
        """
        output = self.conv_block1(x)
        output = self.conv_block2(output)
        output = self.dense_block1(output)
        output = self.dense_block2(output)
        output = self.res_block(output)
        output = self.bottleneck_block(output)
        output = output.view(output.size(0), -1)
        output = self.fc_block(output)
        return output
