# -*- coding:utf-8 -*-

"""
University of Sherbrooke
Date:
Authors: Mamadou Mountagha BAH & Pierre-Marc Jodoin
License:
Other: Suggestions are welcome
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

""" Ces classes implémentent des blocs résiduels (Residual), Dense (Dense) et Goulot (Bottleneck) dans le but 
de les incorporer à une architecture. Pour les implémenter, vous ne devez utiliser que les couches "de base" de
Pytorch, comme Conv2d, BatchNorm2d, ReLu, ainsi que les opérations de bases de Pytorch (sommation, concaténation, etc.)
"""


class ResidualBlock(nn.Module):
    """
    this block is the building block of the residual network. it takes an 
    input with in_channels, applies some blocks of convolutional layers
    to reduce it to out_channels and sum it up to the original input,
    """

    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()
        
        # TODO: la définition des composantes du bloc
	pass
	
    def forward(self, x):
        # TODO: l'utilisation des composantes du bloc pour la propagation avant
        return x


class DenseBlock(nn.Module):
    """
    This block is the building block of the Dense network. It takes an
    input with in_channels, applies some blocks of convolutional, batchnorm layers
    and then concatenate the output with the original input
    """

    def __init__(self, in_channels):
        super(DenseBlock, self).__init__()
        
        # TODO: la définition des composantes du bloc
	pass
	
    def forward(self, x):
        # TODO: l'utilisation des composantes du bloc pour la propagation avant
        return x



class BottleneckBlock(nn.Module):
    """
    This block takes an input with in_channels reduces number of channels by a certain
    parameter "downsample" through kernels of size 1x1, 3x3, 1x1 respectively.
    """

    def __init__(self, in_channels, downsample=4):
        super(BottleneckBlock, self).__init__()
        
        # TODO: la définition des composantes du bloc
	pass
	
    def forward(self, x):
        # TODO: l'utilisation des composantes du bloc pour la propagation avant
        return x

